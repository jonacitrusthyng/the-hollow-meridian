# The Hollow Meridian — Corrected Free Edition v1.0.1

Official corrected free digital edition of *The Hollow Meridian*, a novel by Jona Citrus Thyng.

## Edition facts

- Author: Jona Citrus Thyng
- Corrected edition: v1.0.1, August 24, 2026
- First publication: August 24, 2026
- Completed: August 17, 2026
- Length: 146,332 words
- Structure: Four parts, 30 chapters
- Language: English
- Price: Free
- EPUB UUID: `a434445f-48e0-4eb1-a136-57d111bd96c3`

## Included files

- `The-Hollow-Meridian-Free-Edition.epub` — reflowable ebook
- `The-Hollow-Meridian-Free-Edition.pdf` — 6 × 9-inch fixed-layout reading copy
- `The-Hollow-Meridian-Corrected-Free-Edition-v1.0.1.docx` — editable Word edition
- `The-Hollow-Meridian-v1.0.1-Correction-Log.md` — bounded correction record
- `The-Hollow-Meridian-Cover.png` — portrait cover art
- `The-Hollow-Meridian-Share-Card.png` — wide social preview image
- `metadata.json` — machine-readable publication metadata
- `PLATFORM-COPY.md` — descriptions and keywords for listings
- `SHARING-PERMISSION.txt` — redistribution terms
- `SHA256SUMS.txt` — integrity checksums for every included file except itself

Official site: https://hollow-meridian.doggiepuke.chatgpt.site

Browser reader: https://the-hollow-meridian.doggiepuke.chatgpt.site/read.html

GitHub: https://github.com/jonacitrusthyng/the-hollow-meridian

This is Jona Citrus Thyng's completed novel. It is a separate work from the Royal Road fiction titled *Hollow Meridian* by Peregrine_Onyx.
